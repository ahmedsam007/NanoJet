// Use browser.* if available (Firefox), otherwise fall back to chrome.*
const api = (typeof browser !== 'undefined' ? browser : chrome);

// Intercept new downloads and redirect to idmmac:// scheme
api.downloads.onCreated.addListener(async (item) => {
  try {
    // Only intercept http/https
    if (!item || !item.url || !/^https?:/i.test(item.url)) return;
    // Cancel Chrome's own download
    await api.downloads.cancel(item.id);
    try { await api.downloads.erase({ id: item.id }); } catch (_) {}

    const encoded = encodeURIComponent(item.url);
    // Attempt to open the custom scheme; on macOS this will route to the app
    await api.tabs.create({ url: `idmmac://add?url=${encoded}` });
  } catch (e) {
    console.warn('IDMMac intercept error:', e);
  }
});

// Context menu for links and media (video/audio)
api.runtime.onInstalled.addListener(() => {
  try {
    api.contextMenus.create({
      id: 'idmmac_download_link',
      title: 'Download with IDMMac',
      contexts: ['link']
    });
    api.contextMenus.create({
      id: 'idmmac_download_media',
      title: 'Download video with IDMMac',
      contexts: ['video', 'audio']
    });
  } catch (e) {
    console.warn('Context menu create error:', e);
  }
});

api.contextMenus.onClicked.addListener(async (info, tab) => {
  try {
    let targetUrl = null;
    if (info.menuItemId === 'idmmac_download_link' && info.linkUrl) {
      targetUrl = info.linkUrl;
    } else if (info.menuItemId === 'idmmac_download_media' && info.srcUrl) {
      targetUrl = info.srcUrl;
    }
    if (!targetUrl || !/^https?:/i.test(targetUrl)) return;
    const headers = await buildHeadersForUrl(targetUrl, tab?.url);
    const headersB64 = encodeURIComponent(btoa(unescape(encodeURIComponent(JSON.stringify(headers)))));
    const encoded = encodeURIComponent(targetUrl);
    await api.tabs.create({ url: `idmmac://add?url=${encoded}&headers=${headersB64}` });
  } catch (e) {
    console.warn('Context menu click error:', e);
  }
});

// Handle cookie/header requests from content scripts
api.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;
  if (message.type === 'idmmac_getCookies' && message.url) {
    buildCookieHeader(message.url).then((cookieHeader) => {
      sendResponse({ cookie: cookieHeader });
    }).catch(() => sendResponse({ cookie: '' }));
    return true; // keep the channel open for async response
  }
  if (message.type === 'idmmac_open' && message.url) {
    try {
      const u = encodeURIComponent(message.url);
      const h = message.headersB64 ? `&headers=${encodeURIComponent(message.headersB64)}` : '';
      api.tabs.create({ url: `idmmac://add?url=${u}${h}` });
      sendResponse({ ok: true });
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
    return true;
  }
});

async function buildHeadersForUrl(targetUrl, referer) {
  const headers = {
    'User-Agent': navigator.userAgent
  };
  if (referer) headers['Referer'] = referer;
  const cookie = await buildCookieHeader(targetUrl);
  if (cookie) headers['Cookie'] = cookie;
  return headers;
}

async function buildCookieHeader(targetUrl) {
  try {
    const url = new URL(targetUrl);
    const cookies = await api.cookies.getAll({ url: url.origin });
    if (!cookies || cookies.length === 0) return '';
    const pairs = cookies
      .filter(c => !c.hostOnly || url.hostname.endsWith(c.domain.replace(/^\./, '')))
      .map(c => `${c.name}=${c.value}`);
    return pairs.join('; ');
  } catch (e) {
    return '';
  }
}


