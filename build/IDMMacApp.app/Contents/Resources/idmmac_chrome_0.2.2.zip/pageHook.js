(() => {
  const post = (u) => { try { window.postMessage({ __idmmac_media: true, url: u }, '*'); } catch (e) {} };
  try {
    const of = window.fetch;
    window.fetch = async function(...args) {
      try {
        const u = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) ? args[0].url : '';
        if (u) post(u);
      } catch {}
      return await of.apply(this, args);
    };
  } catch {}
  try {
    const oo = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      try { if (url) post(url); } catch {}
      return oo.apply(this, [method, url, ...rest]);
    };
  } catch {}

  // YouTube: post available formats from ytInitialPlayerResponse when present
  function postYTFormats() {
    try {
      const resp = (window.ytInitialPlayerResponse && window.ytInitialPlayerResponse.streamingData) || null;
      if (!resp) return;
      const formats = [];
      const push = (f) => {
        if (!f) return;
        const url = f.url || f.manifestUrl || '';
        if (!url) return;
        formats.push({ url, label: f.qualityLabel || f.quality || (f.mimeType || '').split(';')[0] || 'Video' });
      };
      (resp.formats || []).forEach(push);
      (resp.adaptiveFormats || []).forEach(push);
      if (resp.hlsManifestUrl) formats.push({ url: resp.hlsManifestUrl, label: 'HLS playlist' });
      if (formats.length) {
        window.postMessage({ __idmmac_yt_formats: true, formats }, '*');
      }
    } catch {}
  }
  // Initial check and on SPA navigations
  try { postYTFormats(); } catch {}
  window.addEventListener('yt-navigate-finish', () => { try { postYTFormats(); } catch {} });
  const ytObs = new MutationObserver(() => { try { postYTFormats(); } catch {} });
  try { ytObs.observe(document.documentElement, { childList: true, subtree: true }); } catch {}
})();


