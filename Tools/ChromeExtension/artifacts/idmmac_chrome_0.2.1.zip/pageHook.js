(() => {
  const post = (u) => { try { window.postMessage({ __idmmac_media: true, url: u }, '*'); } catch (e) {} };
  try {
    const of = window.fetch;
    window.fetch = async function(...args) {
      try {
        const u = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) ? args[0].url : '';
        if (u) post(u);
      } catch {}
      return await of.apply(this, args);
    };
  } catch {}
  try {
    const oo = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      try { if (url) post(url); } catch {}
      return oo.apply(this, [method, url, ...rest]);
    };
  } catch {}
})();


