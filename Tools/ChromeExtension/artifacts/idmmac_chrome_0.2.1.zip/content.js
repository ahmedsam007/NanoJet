(() => {
  const api = (typeof browser !== 'undefined' ? browser : chrome);

  // Simple in-page store of candidate media URLs observed via <video> and network
  const idmmacCandidates = new Set();
  let hasAnyVideo = false;
  let globalBtn;

  // Try hooking fetch/XHR in content world
  try {
    const origFetch = window.fetch;
    window.fetch = async function(...args) {
      tryCaptureURL(args[0]);
      return await origFetch.apply(this, args);
    };
  } catch {}
  try {
    const origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      tryCaptureURL(url);
      return origOpen.apply(this, [method, url, ...rest]);
    };
  } catch {}
  // Also inject a page-context hook so we see real network calls on sites that shadow fetch/XHR (e.g., Telegram)
  // With MV3, we add a second content script in MAIN world (pageHook.js). Here we only listen for messages.
  window.addEventListener('message', (ev) => {
    try {
      const d = ev.data;
      if (d && d.__idmmac_media && typeof d.url === 'string') {
        tryCaptureURL(d.url);
      }
    } catch {}
  });

  function tryCaptureURL(u) {
    try {
      const url = typeof u === 'string' ? u : (u && u.url) ? u.url : '';
      if (!url) return;
      const hasExt = (/\.(mp4|m4v|webm|mov|m3u8)(\?|#|$)/i).test(url);
      const isTelegramStream = (/web\.telegram\.org\/.+\/stream\//i).test(url) || (/mimeType%22:%22video\//i).test(url);
      if (hasExt || isTelegramStream) {
        idmmacCandidates.add(url);
      }
    } catch {}
  }

  function createOverlay(video) {
    const wrapper = document.createElement('div');
    wrapper.className = 'idmmac-overlay';
    const button = document.createElement('button');
    button.className = 'idmmac-btn';
    button.title = 'Download with IDMMac';
    button.textContent = 'Download';
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      tryOpenMenu(video, button);
    });
    wrapper.appendChild(button);
    document.body.appendChild(wrapper);
    positionOverlay(wrapper, video);
    const ro = new ResizeObserver(() => positionOverlay(wrapper, video));
    ro.observe(video);
    const so = () => positionOverlay(wrapper, video);
    window.addEventListener('scroll', so, { passive: true });
    window.addEventListener('resize', so, { passive: true });
  }

  function positionOverlay(wrapper, video) {
    const rect = video.getBoundingClientRect();
    // Place at top-right inside the video bounds with margin
    const top = rect.top + window.scrollY + 8;
    const left = rect.left + window.scrollX + Math.max(8, rect.width - 110);
    wrapper.style.position = 'absolute';
    wrapper.style.zIndex = 2147483646;
    wrapper.style.top = `${Math.max(8, top)}px`;
    wrapper.style.left = `${Math.max(8, left)}px`;
    wrapper.style.display = rect.width > 80 && rect.height > 60 ? 'block' : 'none';
  }

  function tryOpenMenu(video, anchorButton) {
    const sources = collectVideoSources(video);
    // Merge with network-observed candidates
    idmmacCandidates.forEach((u) => {
      if (!sources.some((s) => s.url === u)) {
        sources.push({ url: u, label: inferLabel(u) });
      }
    });
    if (!sources.length && video.currentSrc) {
      sources.push({ url: video.currentSrc, label: inferLabel(video.currentSrc) });
    }
    if (!sources.length) return;
    showMenu(anchorButton, sources);
  }

  function collectVideoSources(video) {
    const list = [];
    if (video.src) list.push({ url: video.src, label: inferLabel(video.src) });
    video.querySelectorAll('source').forEach((s) => {
      const url = s.src || s.getAttribute('src');
      if (url) list.push({ url, label: s.getAttribute('label') || s.getAttribute('res') || inferLabel(url) });
    });
    const dataUrl = video.getAttribute('data-src') || video.getAttribute('data-url');
    if (dataUrl) list.push({ url: dataUrl, label: inferLabel(dataUrl) });
    const seen = new Set();
    return list.filter((it) => {
      try { new URL(it.url); } catch { return false; }
      const k = it.url.split('#')[0];
      if (seen.has(k)) return false;
      seen.add(k); return true;
    });
  }

  function inferLabel(url) {
    const m = /([0-9]{3,4})p(?![a-z])/i.exec(url) || /_(\d{3,4})\./i.exec(url);
    if (m) return `${m[1]}p`;
    if (/\.m3u8(\?|#|$)/i.test(url)) return 'HLS playlist';
    if (/\.mp4(\?|#|$)/i.test(url)) return 'MP4';
    return 'Video';
  }

  function showMenu(anchor, sources) {
    closeMenu();
    const menu = document.createElement('div');
    menu.className = 'idmmac-menu';
    sources.forEach((s) => {
      const item = document.createElement('div');
      item.className = 'idmmac-menu-item';
      item.textContent = `Download ${s.label}`;
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        sendToApp(s.url);
        closeMenu();
      });
      menu.appendChild(item);
    });
    document.body.appendChild(menu);
    const r = anchor.getBoundingClientRect();
    menu.style.position = 'absolute';
    menu.style.zIndex = 2147483647;
    menu.style.top = `${r.bottom + window.scrollY + 4}px`;
    menu.style.left = `${r.left + window.scrollX}px`;
    setTimeout(() => {
      window.addEventListener('click', closeMenu, { once: true });
    }, 0);
  }

  function closeMenu() {
    const m = document.querySelector('.idmmac-menu');
    if (m) m.remove();
  }

  function sendToApp(url) {
    try {
      const api = (typeof browser !== 'undefined' ? browser : chrome);
      const buildAndOpen = (cookieHeader) => {
        try {
          const headers = {
            Referer: location.href,
            Origin: location.origin,
            'User-Agent': navigator.userAgent
          };
          if (cookieHeader && cookieHeader.trim().length > 0) {
            headers['Cookie'] = cookieHeader;
          } else if (new URL(url).origin === location.origin) {
            // Fallback: same-origin non-HttpOnly cookies accessible to JS
            const c = document.cookie;
            if (c && c.trim().length > 0) headers['Cookie'] = c;
          }
          const json = JSON.stringify(headers);
          const b64 = btoa(unescape(encodeURIComponent(json)));
          // Prefer messaging the service worker to open the custom scheme; some sites block window.open
          api.runtime.sendMessage({ type: 'idmmac_open', url, headersB64: b64 }, (resp) => {
            // Fallback to window.open if messaging fails
            if (!resp || resp.ok !== true) {
              try {
                const urlParam = encodeURIComponent(url);
                const headersParam = encodeURIComponent(b64);
                window.open(`idmmac://add?url=${urlParam}&headers=${headersParam}`,'_blank');
              } catch (e) {
                console.warn('IDMMac fallback open error', e);
              }
            }
          });
        } catch (e) {
          console.warn('IDMMac build/open error', e);
        }
      };
      // Ask background for cookies (can include HttpOnly)
      try {
        api.runtime.sendMessage({ type: 'idmmac_getCookies', url }, (resp) => {
          const cookieHeader = resp && resp.cookie ? resp.cookie : '';
          buildAndOpen(cookieHeader);
        });
      } catch (_) {
        buildAndOpen('');
      }
    } catch (e) {
      console.warn('IDMMac video send error', e);
    }
  }

  function scanRoot(root) {
    try {
      root.querySelectorAll('video').forEach((v) => {
        hasAnyVideo = true;
        if (v.dataset.idmmacBound) return;
        v.dataset.idmmacBound = '1';
        createOverlay(v);
      });
    } catch {}
    // Recurse into open shadow roots
    try {
      root.querySelectorAll('*').forEach((el) => {
        if (el.shadowRoot) scanRoot(el.shadowRoot);
      });
    } catch {}
  }

  function scan() {
    hasAnyVideo = false;
    scanRoot(document);
    ensureGlobalButton();
  }

  const observer = new MutationObserver(() => scan());
  observer.observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener('load', scan);
  document.addEventListener('DOMContentLoaded', scan);
  setInterval(scan, 2000);

  // Global fallback button for sites where <video> overlay is blocked (e.g., Telegram Web)
  function ensureGlobalButton() {
    try {
      const shouldShow = hasAnyVideo || idmmacCandidates.size > 0;
      if (globalBtn) {
        globalBtn.style.display = shouldShow ? 'block' : 'none';
        return;
      }
      if (!shouldShow) return;
      globalBtn = document.createElement('button');
      globalBtn.className = 'idmmac-global-btn';
      globalBtn.textContent = 'Download Video';
      globalBtn.title = 'Download with IDMMac';
      Object.assign(globalBtn.style, {
        position: 'fixed',
        right: '12px',
        bottom: '12px',
        zIndex: '2147483647',
        padding: '8px 10px',
        background: '#0b5fff',
        color: '#fff',
        border: 'none',
        borderRadius: '8px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.25)',
        cursor: 'pointer',
        fontSize: '12px'
      });
      globalBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const list = collectGlobalSources();
        if (!list.length) return;
        showMenu(globalBtn, list);
      });
      document.body.appendChild(globalBtn);
    } catch {}
  }

  function collectGlobalSources() {
    const sources = [];
    idmmacCandidates.forEach((u) => sources.push({ url: u, label: inferLabel(u) }));
    try {
      document.querySelectorAll('video').forEach((v) => {
        if (v.currentSrc) sources.push({ url: v.currentSrc, label: inferLabel(v.currentSrc) });
      });
    } catch {}
    const seen = new Set();
    return sources.filter((s) => {
      const k = (s.url || '').split('#')[0];
      if (seen.has(k)) return false; seen.add(k); return true;
    });
  }
})();
